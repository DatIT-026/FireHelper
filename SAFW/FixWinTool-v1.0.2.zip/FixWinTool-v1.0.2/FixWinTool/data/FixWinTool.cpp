#include <bits/stdc++.h>
#include <windows.h>
using namespace std;

int main()
{
    int i, nhapso;
    for (i = 0;i <= 5; i++){
        system("cls");
        cout << "\n\t\t\t\tLoading  "<< i << " /5"<< endl;
            Sleep(10);
        }
        Sleep(100);
        
        system("cls");

        cout << "           Welcome to Fix Win Tool v1.0.2 " << endl;
        cout << "        	Created by DatIT" << endl;
        cout << "   ---------------------------------------------------" << endl;
        cout << "        Sua loi Windows Update: Nhap (1)" << endl;
        cout << "        Sua loi Wifi: Nhap (2)" << endl;
        cout << "        Sua loi Hieu Suat: Nhap (3)" << endl;
        cout << "        Thong so may tinh: Nhap (4)" << endl;
        cout << "        Tinh trang ban quyen Windows: Nhap (5)" << endl;
        cout << "        Thoat chuong trinh: Nhap (6)" << endl;
        cout << "   ---------------------------------------------------" << endl;
        
        cout << "              Nhap lua chon cua ban: ";
    	cin >> nhapso;
        

        if (nhapso == 1){
            system("cls");
            cout << "Starting Windows Troubleshooter...";
        	system("WinUpdate.bat");
            cout << "\nDone! Please wait...";
            Sleep(2000);

            system("FixWinTool.exe") ;
		}

        if (nhapso == 2){
            system("cls");
            system("FixWifi.bat");

            system("ipconfig/release");
            system("cls");
            system("ipconfig/renew");
            system("echo ---------------------------------------------------");
            cout << "Done! Please wait...";
            Sleep(3000);

            system("FixWinTool.exe") ;
        }

        if (nhapso == 3){
            system("cls");
            cout << "Starting Windows Troubleshooter...";
            system("PerformanceDiagnostic.bat");
            cout << "\nDone! Please wait...";
            Sleep(2000);

            system("FixWinTool.exe") ;
        }

        int thongso;
        if (nhapso == 4){
            system("cls");
            cout << "              Vui long chon che do" << endl;
            cout << "   ---------------------------------------------------" << endl;
            cout << "        Xem thong so may 1: Nhap (1)" << endl;
            cout << "        Xem thong so may 2: Nhap (2)" << endl;
            cout << "   ---------------------------------------------------" << endl;

            cout << "              Nhap lua chon cua ban: ";
            cin >> thongso;

            if(thongso == 1){
                cout << "                 Please wait...";
                system("dxdiag");
            }
            if(thongso == 2){
                cout << "                 Please wait...";
                system("msinfo32");
            }

                system("FixWinTool.exe");
        }

        if (nhapso == 5){
            system("cls");
            cout << "                 Please wait..." << endl;
            system("slmgr.vbs /dli");
            system("slmgr.vbs /xpr");
            system("echo    ---------------------------------------------------");
            cout << "            	Done! Please wait...";
            Sleep(2000);
            system("FixWinTool.exe");
        }

        bool out;
        if (nhapso == 6){
            system("cls");
            cout << "           Ban muon thoat chuong trinh?" << endl;
            cout << "   ---------------------------------------------------" << endl;
            cout << "        Co: Nhap (1)" << endl;
            cout << "        Khong: Nhap (0)" << endl;
            cout << "   ---------------------------------------------------" << endl;

            cout << "        Nhap lua chon cua ban: ";
            cin >> out;

            if(out == 1){
                cout << "                   Dang thoat..." << endl;
                system("outw.vbs");
                system("exit");
                system("exit");
            }
            if(out == 0){
                system("FixWinTool.exe");
            }
            system("exit");
        }
}
