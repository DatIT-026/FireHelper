﻿	-------------------------THÔNG TIN-------------------------

*LƯU Ý: VUI LÒNG CHẠY VỚI TƯ CÁCH QUẢN TRỊ VIÊN (RUN AS ADMINISTRATOR) 
TRƯỚC KHI KHỞI ĐỘNG CHƯƠNG TRÌNH.
*NOTE: YOU MUST RUN AS ADMINISTRATOR BEFORE USING THIS TOOL.

Thông tin và chức năng của chương trình qua các bản cập nhật:

v1.1.0 (Bản mới nhất)
- Cập nhật một số tính năng mới.
(Đặc Biệt: Tích hợp với Tool Microsoft Activation Scripts AIO)
- Chỉnh sửa, loại bỏ, bổ sung và cải thiện một số tính năng.
(Đặc Biệt: Cải thiện tính năng Activation Status)
- Cập nhật giao diện mới tương thích trên các phiên bản Windows.
(Bao Gồm: Windows 7, Windows 10, Windows 11)
- Sửa lỗi và cập nhật tính năng Update.
- Tăng hiệu suất và tối ưu Tool.

v1.0.9
- Cập nhật tính năng Update
- Sửa lỗi hiện màn hình
- Chỉnh lại giao diện

v1.0.8
- Fix Bug
- Thêm tính năng cập nhật tool
- Xoá bỏ tính năng thừa

v1.0.7
- Fix Bug
- Cập nhật giao diện mới
- Cập nhật một số tính năng mới (Đặc biệt: Dark Mode)
- Gỡ bỏ một số tính năng thừa

v1.0.6
- Fix Bug
- Fix lỗi crash trên Windows 7
- Cập nhật một số tính năng mới
- Gỡ bỏ một số tính năng thừa

v1.0.5
- Fix Bug
- Cập nhật thêm một số tính năng mới
- Gỡ bỏ một số tính năng thừa

v1.0.4
- Fix Bug
- Cập nhật giao diện mới
- Cập nhật thêm một số tính năng mới

v1.0.3
- Fix Bug
- Sửa lỗi Crash
- Cập nhật giao diện mới
- Cập nhật thêm một số tính năng mới
- Lượt bớt một số tính năng không cần thiết

v1.0.2
- Cập nhật tính năng Sửa lỗi Windows Update
- Cập nhật tính năng Sửa lỗi Hiệu Suất
- Cập nhật tính năng Kiểm tra bản quyền Windows
- Sửa lỗi không chạy được một số tính năng

v1.0.1
- Sửa lỗi không chạy được một số tính năng
- Sửa lỗi Crash

--------------------------------------------------------------------------------
Program: SETUP AND FIX WINDOWS TOOL
For Support:
- FanPage: https://www.facebook.com/hanguyentiendat2006
- Mobile Phone: 0948147172
- Website: https://firehelper.cf/
--------------------------------------------------------------------------------
©Copyright by DatIT. All right reserved.