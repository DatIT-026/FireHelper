﻿	-------------------------THÔNG TIN-------------------------

*LƯU Ý: VUI LÒNG CHẠY RUN AS ADMINISTRATOR KHI KHỞI ĐỘNG CHƯƠNG TRÌNH
*NOTE: YOU MUST BE AN ADMINISTRATOR RUNNING A CONSOLE SESSION IN ORDER TO
USE THIS TOOL.

Thông tin và chức năng của chương trình qua bản cập nhật:

v1.0.8 (Bản mới nhất)
- Fix Bug
- Thêm tính năng cập nhật tool
- Xoá bỏ tính năng thừa

v1.0.7
- Fix Bug
- Cập nhật giao diện mới
- Cập nhật một số tính năng mới (Đặc biệt: Dark Mode)
- Gỡ bỏ một số tính năng thừa

v1.0.6
- Fix Bug
- Fix lỗi crash trên Windows 7
- Cập nhật một số tính năng mới
- Gỡ bỏ một số tính năng thừa

v1.0.5
- Fix Bug
- Cập nhật thêm một số tính năng mới
- Gỡ bỏ một số tính năng thừa

v1.0.4
- Fix Bug
- Cập nhật giao diện mới
- Cập nhật thêm một số tính năng mới

v1.0.3
- Fix Bug
- Sửa lỗi Crash
- Cập nhật giao diện mới
- Cập nhật thêm một số tính năng mới
- Lượt bớt một số tính năng không cần thiết

v1.0.2
- Cập nhật tính năng Sửa lỗi Windows Update
- Cập nhật tính năng Sửa lỗi Hiệu Suất
- Cập nhật tính năng Kiểm tra bản quyền Windows
- Sửa lỗi không chạy được một số tính năng

v1.0.1
- Sửa lỗi không chạy được một số tính năng
- Sửa lỗi Crash

--------------------------------------------------------------------------------
Program: SETUP AND FIX WINDOWS TOOL
Last version: v1.0.7
For Support:
- FanPage: https://www.facebook.com/hanguyentiendat2006
- Mobile Phone: 0948147172
- Website: https://firehelper.cf/
--------------------------------------------------------------------------------
©Copyright by DatIT. All right reserved.