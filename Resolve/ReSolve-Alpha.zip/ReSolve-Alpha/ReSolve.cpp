#include <iostream>
#include <math.h>
#include <string.h>
#include <string>
#include <map>
#define PI 3.1415926535898
using namespace std;

//Thong tin tac gia chuong trinh
void Info(){
    system("cls");
    cout<<"\n                     CHUONG TRINH TINH TOAN  ";
            cout<<"\n     ==================================================";
            
    cout<<"\n           Tac gia    : Ha Nguyen Tien Dat - DatIT"<< endl;
    cout<<"\n           Email      : tiendatha2006@gmail.com"<<endl;
    cout<<"\n           Website    : http://firehelper.cf/"<<endl;
	cout<<"\n           Version    : Alpha";
	        cout<<"\n     ==================================================\n\n";
    system("pause");
    system("cls");
}

//TIM SO NGUYEN TO
void SoNguyen(){
	system("cls");
    long n;
        cout<<"\n       TIM SO NGUYEN, BOI VA UOC  "<<endl;
        cout << "-------------------------------------\n\n";
	    cout << "Nhap so nguyen n = ";
	    //Tim uoc
	    do{
	        cin >> n;
	        cout << "\n-------------------------------------\n";
	        if(n <= 0 || n > 1000000){
	            cout << "\nNhap lai so nguyen n = ";
	        }
	    }
		while(n <= 0 || n > 1000000);
	    
	    cout << "\nUoc cua " << n << " la: ";
	    
	    for(int i = 1; i <= n; i++){
	        if(n % i == 0){
				cout << i << " ";
	        }
	    }
	    
	    cout << "\nBoi cua " << n << " la: 0 ";
	    
	    //Tim boi
	    	for(int i = n; i >= n && i < n + 100; i++){
	    		if(i % n == 0){
	    			cout << i << " ";
				}
			}
	    
	    //Tim so nguyen to
	    if(n < 2){
	        cout << n << " khong phai so nguyen to\n";
	    }
	    int count = 0;
	    for(int i = 2; i <= sqrt(n); i++){
	        if(n % i == 0){
	            count++;
	        }
	    }
	    if(count == 0){
	    	cout << endl;
	        cout << n << " la so nguyen to\n";
	    }
		else{
			cout << endl;
	        cout << n << " khong phai so nguyen to\n";
	    }
	    cout << "\n-------------------------------------\n";
	    system("pause");
	    system("cls");
	    system("ReSolve.exe");
}

//CAN BANG PTHH
void PTHH(){
	system("PTHH.exe");
}

//PHUONG TRINH BAC 2
void PTB2(){
	system("PTB2.exe");
}


int main(){
	
	cout <<"\n                CHUONG TRINH TINH TOAN - Alpha       ";
        cout<<"\n     ==================================================";
        cout<<"\n     |1. Tinh so nguyen va tim uoc, boi               |";
        cout<<"\n     |2. Giai PTB2 co dang ax^2 + bx + c = 0          |";
        cout<<"\n     |3. Can bang PTHH (Coming Soon)                  |";
        cout<<"\n     ==================================================";
        cout<<"\n     |              Press 0: Information              |";              
        cout<<"\n     ==================================================";
        cout<<"\n       Vui Long Chon Cac Phim Chuc Nang Tuong Ung: ";

	float a, b, c, d;
	int chon;
    cin >> chon;

        if(chon == 0){
            Info();
            system("ReSolve.exe");
        }

        else if(chon == 1){
            SoNguyen();
        }
        else if(chon == 2){
            PTB2();
            system("ReSolve.exe");
        }
        else if(chon == 4){
            PTHH();
            system("ReSolve.exe");
        }
    return 0;
}
	
	
